enum UserState{
  Offline,
  Online,
  Waiting,
}
