enum ViewState{

  IDLE,
  LOADING,

}