import 'dart:ui';

import 'package:flutter/material.dart';

BoxDecoration roundedF3Box = BoxDecoration(
    borderRadius: BorderRadius.circular(10), color: Color(0xffF3F4F8));
