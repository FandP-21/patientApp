
class CurrentPatient {
  
}